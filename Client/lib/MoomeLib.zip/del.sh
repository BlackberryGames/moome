#!/bin/bash
rm *.class &>/dev/null
rm com/moome/*.class &>/dev/null
rm com/moome/leveleditor/*.class &>/dev/null
exit 0
