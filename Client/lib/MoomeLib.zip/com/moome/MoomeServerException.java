package com.moome;


public class MoomeServerException extends Exception {

}
