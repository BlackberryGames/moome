package com.moome;

public class Cutscene {
    int x;
    int y;
    CutsceneScreen screen;
    
    public Cutscene(int a, int b, CutsceneScreen s) {
        x = a;
        y = b;
        screen = s;
    }
}
